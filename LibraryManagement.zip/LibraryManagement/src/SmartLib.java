import com.zsgs.smartlib.features.registration.RegistrationView;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class SmartLib {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.println("Hello and welcome!");
       new RegistrationView().init();
//       new DetailsView().init();
//       new ManageView().init();
//       new SearchView().init();
//       new LibrarySetupView().init();
//       new BorrowBooksView().init();
//       new FeedbackView().init();
//       new FineView().init();
//       new SearchView().init();
    }
}
//        Enter Name :
//        Raj
//        Enter Username :
//        Murugan
//        Enter Password :
//        Raj@12324
//        Confirm Password :
//        Raj@12324