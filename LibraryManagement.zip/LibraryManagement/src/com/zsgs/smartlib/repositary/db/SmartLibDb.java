package com.zsgs.smartlib.repositary.db;

import com.zsgs.smartlib.repositary.dto.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SmartLibDb {
    public static SmartLibDb smartlibdb;


    //public static Object getInstance;
    private List<RegistrationInfo> users = new ArrayList<>();
    private Library library;

    private List<Books> books = new ArrayList<>();
    private Map<String,List<String>> borrowedbookrecords = new HashMap<>();
    private List<BorrowedBooks> borrowedBooks = new ArrayList<>();

    //private List<User> Loginusers = new ArrayList<>();
    public void addUser(RegistrationInfo info){
        users.add(info);
    }
    private SmartLibDb(){
    }
    public static SmartLibDb getInstance(){
        if(smartlibdb==null){
            smartlibdb= new SmartLibDb();
        }
        return smartlibdb;
    }
//
//   public void borrowedBook(){
//      for(BorrowedBooks record : borrowedBooks){
//          String userId = record.getUserId();
//          String BookId = record.getBookId();
//          borrowedbookrecords.putIfAbsent(userId,new ArrayList<>());
//          borrowedbookrecords.get(userId).add(BookId);
//      }
//    }public void borrowBook(String userId, String bookId) {
//
//
//        borrowedBook.setUserId(userId);
//        borrowedBook.setBookId(bookId);
//
//        // Add to the list
//        borrowedBooks.add(borrowedBook);
//
//        borrowedBook();
//    }





    private RegistrationInfo registrationinfo;
      public RegistrationInfo getRegistrationinfo(){

          return registrationinfo;
      }
      public void setRegistrationinfo(RegistrationInfo registrationinfo){
          this.registrationinfo = registrationinfo;
      }


    public RegistrationInfo getUserbyUserName(String userName) {
        for(RegistrationInfo user : users){
            if(user.getUserName().equalsIgnoreCase(userName)){
                return user;
            }
        }return null;
    }
//   public void printAllUsers() {
//       if (users != null) {
//           System.out.println("No registred Users");
//           System.out.println(users);
//       }
//       for (RegistrationInfo user : users) {
//           System.out.println("UserName " + user.getUserName());
//           System.out.println("password" + user.getPassword());
//           System.out.println("list" + user);
//       }
//   }

    public Library getLibrary() {
        return library;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }
  public void addBook(Books book){
          books.add(book);
  }
  public List<Books> getAllBooks(){
          return new ArrayList<>(books);
  }
//  public List<BorrowedBooks> getAllBorrowedBooks(){
//          return new ArrayList<>(borrowedBooks);
//  }
//  public void addUser(User user){
//          Loginusers.add(user);
//  }
    public List<RegistrationInfo> getAllRegisteredUsers(){
          return new ArrayList<>(users);
    }



    public boolean validateLoginInfo(String userName, String password) {
          for(RegistrationInfo user : users){
              if(user.getUserName().equalsIgnoreCase(userName) && user.getPassword().equalsIgnoreCase(password)){
                  return true;
              }
          }return false;
    }

    public void borrowBook(String userId, String bookId) {
        BorrowedBooks borrowedBook = new BorrowedBooks();

        borrowedBook.setUserId(userId);
        borrowedBook.setBookId(bookId);
        borrowedBook.setBorrowDate(System.currentTimeMillis());

        long dueDate = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000);
        borrowedBook.setDueDate(dueDate);

        borrowedBook.setReturned(false);
        borrowedBook.setFineAmount(0);

        borrowedBooks.add(borrowedBook);
    }

    public List<BorrowedBooks> getBorrowedBooksByUser(String userId) {
        List<BorrowedBooks> userBooks = new ArrayList<>();
        for (BorrowedBooks book : borrowedBooks) {
            if (book.getUserId().equals(userId)) {
                userBooks.add(book);
            }
        }
        return userBooks;
    }


}
