package com.zsgs.smartlib.repositary.dto;

public class Login {
    String username;
    String password;
}
