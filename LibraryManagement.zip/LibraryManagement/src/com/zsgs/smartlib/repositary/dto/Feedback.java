package com.zsgs.smartlib.repositary.dto;

public class Feedback {

    String mailId;
    String user;
    String message;
}
