package com.zsgs.smartlib.repositary.dto;
import java.util.List;

public class StorageStructure {
     public List<Rows> shelf;
}
