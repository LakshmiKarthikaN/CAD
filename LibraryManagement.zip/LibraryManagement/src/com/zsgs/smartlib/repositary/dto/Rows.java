package com.zsgs.smartlib.repositary.dto;

public class Rows {
    String title;
    String bookId;

    
}
