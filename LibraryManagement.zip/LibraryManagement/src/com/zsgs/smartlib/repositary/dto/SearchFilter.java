package com.zsgs.smartlib.repositary.dto;

public class SearchFilter {
    String title;
    String BookId;
}
