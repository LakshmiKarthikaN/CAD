package com.zsgs.smartlib.repositary.dto;

public class FineAmount {
    int transactionId;
    int days;
    //User user;
    //Book book;
    //Date rentDate;
    //Date dueDate;
    double fine;
    //Date returnDate;
    boolean isReturned;
}
