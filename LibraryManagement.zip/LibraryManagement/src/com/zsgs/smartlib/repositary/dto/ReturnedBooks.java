package com.zsgs.smartlib.repositary.dto;

public class ReturnedBooks {
    String title;
    String bookId;

}
