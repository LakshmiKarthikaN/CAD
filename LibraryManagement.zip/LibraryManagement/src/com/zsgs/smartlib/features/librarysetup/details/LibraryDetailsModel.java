package com.zsgs.smartlib.features.librarysetup.details;

public class LibraryDetailsModel {
    LibraryDetailsView view;
    public LibraryDetailsModel(LibraryDetailsView view){
        this.view = view;
    }
    public void init(){

    }
}
