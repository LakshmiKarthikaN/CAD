package com.zsgs.smartlib.features.librarysetup;

import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.Library;

class LibrarySetupModel {
    private final LibrarySetupView view;


    public LibrarySetupModel(LibrarySetupView librarysetupView){

         this.view = librarysetupView;
     }
     void init(){
          if(SmartLibDb.getInstance().getLibrary()==null){
              view.proceedToSettheLibrary();

          }else{
              view.onLibrarySetupCompleted();          }
         //System.out.println("LibrarySetupModel "+view);
     }void setupLibrary(Library library) {
        if(validateLibraryInfo(library)) {
            SmartLibDb.getInstance().setLibrary(library);
            view.onLibrarySetupCompleted();
        }else {
            view.showErrorMessage("Invalid library information please try again.");
        }
    }
    private boolean validateLibraryInfo(Library library) {

        return library != null &&
                library.getName() != null && !library.getName().trim().isEmpty() &&
                library.getAddress() != null && !library.getAddress().trim().isEmpty() &&
                library.getPhoneNo() != null && library.getPhoneNo().matches("\\d{10}") &&
                library.getEmailId() != null && library.getEmailId().matches("^[A-Za-z0-9+_.-]+@(.+)$") &&
                library.getIncharge() != null && !library.getIncharge().trim().isEmpty();
    }

}



