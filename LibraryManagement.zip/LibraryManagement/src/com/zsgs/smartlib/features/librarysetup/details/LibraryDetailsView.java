package com.zsgs.smartlib.features.librarysetup.details;

public class LibraryDetailsView {
    LibraryDetailsModel model;
    public LibraryDetailsView(){
        model = new LibraryDetailsModel(this);
    }
    public void init(){

    }
}
