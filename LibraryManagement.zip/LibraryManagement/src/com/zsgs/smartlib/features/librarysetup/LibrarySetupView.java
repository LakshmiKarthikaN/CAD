package com.zsgs.smartlib.features.librarysetup;

import com.zsgs.smartlib.features.base.BaseView;
import com.zsgs.smartlib.repositary.dto.Library;

import java.util.Scanner;

public class LibrarySetupView extends BaseView {
    private final LibrarySetupModel model;
    private final Scanner scanner = new Scanner(System.in);

    public LibrarySetupView() {
        model = new LibrarySetupModel(this);
    }

    public void init() {
        model.init();
    }

    public void proceedToSettheLibrary() {
        System.out.println("\n === Library Set up ===");
        Library library = new Library();
        library.setName(getLibraryName());
        library.setAddress(getAddress());
        library.setPhoneNo(getPhoneNo());
        library.setEmailId(getEmail());
        library.setIncharge(getIncharge());
        library.setCapacity(getCapacity());
        library.setOpenTime(getOpenTime());
        library.setCloseTime(getCloseTime());
        library.setNoAvailableDays(getAvailableDays());
        model.setupLibrary(library);

    }


    private String getLibraryName() {
        String name = " ";
        System.out.println("Enter Library Name : ");
        do {
            name = scanner.nextLine();
            if (name.length() < 3 || name.length() > 50) {
                System.out.println("Library Name should be between 3 and 50 chararcter\nEnter valid name : ");
            } else break;
        } while (true);
        return name;
    }

    private String getAddress() {
        String address = " ";
        System.out.println("Enter the Address : ");
        do {
            address = scanner.nextLine();
            if (address.length() < 10 || address.length() > 100) {
                System.out.println("Address should be between 10 and 100 Characters\n Enter valid address : ");
            } else break;
        } while (true);
        return address;
    }

    private String getPhoneNo() {
        String phoneNO = " ";
        System.out.println("Enter the PhoneNo : ");
        do {
            phoneNO = scanner.nextLine();

            if (!phoneNO.matches("\\d{10}")) {
                System.out.println("The phone number should be 10 digits\nEnter valid Phone Number :  ");
            } else break;

        } while (true);
        return phoneNO;
    }

    private String getEmail() {
        String email = " ";
        System.out.println("Enter the Email :");
        do {
            email = scanner.nextLine();
            if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$"))
                System.out.println("Invalid email format\nEnter valid email:");
            else break;
        } while (true);
        return email;
    }

    private String getIncharge() {
        String incharge = " ";
        System.out.println("Enter the Incharge Name :");
        do {
            incharge = scanner.nextLine();
            if (incharge.length() < 3 || incharge.length() > 50) {
                System.out.println("Incharge name should be between 3 and 50 character\n Enter ");
            } else break;
        } while (true);
        return incharge;
    }

    private Integer getCapacity() {
        Integer capacity = null;
        System.out.println("Enter the Capacity : ");
        do {
            try {
                capacity = Integer.parseInt(scanner.nextLine());
                if (capacity <= 0)
                    System.out.println("The capacity should be greater than 0\nEnter the Valid Capacity : ");
                else break;
            } catch (NumberFormatException e) {
                System.out.println("Please Enter a Valid Capacity Number\nEnter the valid Capacity : ");
            }
        } while (true);
        return capacity;
    }

    private Long getOpenTime() {
        Long time = null;
        System.out.println("Enter the Opening Time (in 24-hours format, e.g., 900 for 9:00AM) :");
        do {
            try {
                time = Long.parseLong(scanner.nextLine());
                if (time < 0 || time > 2359) {
                    System.out.println("Time should be between 0000 and 2359\nEnter valid time : ");
                } else break;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid time\nEnter valid Time: ");
            }
        } while (true);
        return time;
    }

    private Long getCloseTime() {
        Long time = null;
        System.out.println("Enter Closing Time(in 24 hours format,e.g.,1800 for 6:))PM):");
        do {
            try {
                time = Long.parseLong(scanner.nextLine());
                if (time < 0 || time > 2359)
                    System.out.println("Time should be between 0000 and 2359\n Enter valid Time: ");
                else break;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid time\nEnter valid time : ");
            }
        } while (true);
        return time;
    }

    private Integer getAvailableDays() {
        Integer days = null;
        System.out.println("Enter Number of Available Days per Week (1-7):");
        do {
            try {
                days = Integer.parseInt(scanner.nextLine());
                if (days < 1 || days > 7)
                    System.out.println("Days should be between 1 and 7\nEnter valid days:");
                else break;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number\nEnter valid days:");
            }
        } while (true);
        return days;
    }

    public void onLibrarySetupCompleted() {
        System.out.println("\nLibrary setup completed successfully!");
        showMainMenu();
    }

    public void showMainMenu() {
        while (true) {
            System.out.println("\n=== SmartLib Main Menu ===");
            System.out.println("1. Manage Books");
            System.out.println("2. View Books");
            System.out.println("3. Manage Users");
            System.out.println("4. View Users");
            System.out.println("5. View Library Details");
            System.out.println("6. Logout");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        new com.zsgs.smartlib.features.books.manage.ManageView().init();
                        break;
                    case 2:
                        new com.zsgs.smartlib.features.books.BooksView().init();
                        break;
                    case 3:
                        new com.zsgs.smartlib.features.users.manage.ManageView().init();
                        break;
                    case 4:
                        new com.zsgs.smartlib.features.users.UsersView().init();
                        break;
                    case 5:
                        new com.zsgs.smartlib.features.librarysetup.details.LibraryDetailsView().init();
                        break;
                    case 6:
                        System.out.println("Logged in successfully");
                        new com.zsgs.smartlib.features.registration.RegistrationView().init();
                        break;
                    case 7:
                        exitApp();
                        break;
                    default:
                        System.out.println("please enter the correct choice");
                }
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid number");
            }
        }
    }
    public void showErrorMessage(String message){
        System.out.println(message);
        proceedToSettheLibrary();
    }


}




