package com.zsgs.smartlib.features.registration;
import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.RegistrationInfo;

import java.util.List;

class RegistrationModel {
    private final  RegistrationView view;
    public RegistrationModel(RegistrationView registrationview){

        view = registrationview;
    }

    void init() {
        if (!SmartLibDb.getInstance().getAllRegisteredUsers().isEmpty()) {
            view.proceedLogin();
        } else {
            view.ProceedRegistration();
        }
    }

    void registeruser(RegistrationInfo info) {
        if (ifAlreadyExist(info.getUserName())) {
            view.showErrorMessage("User name already exists...");
        } else if (isWeakPassword(info)) {
            view.showErrorMessage("Please enter a strong password.");
       }
//        else if (isPasswordMismatch(info)) {
//            view.showErrorMessage("The password doesn't match.");
//        }
       else {
            SmartLibDb.getInstance().addUser(info);
            SmartLibDb.getInstance().setRegistrationinfo(info);

            //SmartLibDb.getInstance().printAllUsers();
            view.onRegistrationSuccess();
        }
        System.out.println("registered Users");
       for(RegistrationInfo u : SmartLibDb.getInstance().getAllRegisteredUsers()){
           System.out.println(u.getUserName());
           System.out.println(u.getPassword());
       }
    }


//    private boolean isPasswordMismatch(RegistrationInfo info) {
//        return !info.getPassword().equals(info.getConfirmPassword());
//    }

    private boolean isWeakPassword(RegistrationInfo info) {
       String pwd= String.valueOf(info.getPassword());

        boolean hasUppercase = pwd.matches(".*[A-Z].*");
        boolean hasLowercase = pwd.matches(".*[a-z].*");
        boolean hasDigit = pwd.matches(".*\\d.*");
        boolean hasSpecialChar = pwd.matches(".*[!@#$%^&*(),.?\":{}|<>].*");

        return !(hasUppercase && hasLowercase && hasDigit && hasSpecialChar);
    }

    private boolean ifAlreadyExist(String userName) {
        List<RegistrationInfo> allusers = SmartLibDb.getInstance().getAllRegisteredUsers();
        for(RegistrationInfo user : allusers){
            if(user.getUserName().equalsIgnoreCase(userName)){
                return true;
            }
        }return false;
    }

    public void validateCredentials(String userName,String password) {
        if(SmartLibDb.getInstance().validateLoginInfo(userName,password)){
            view.onSuccessLogin(userName);
        }else{
            view.onInvalidCredentials();
        }
    }


}
