package com.zsgs.smartlib.features.borrowbooks;

import com.zsgs.smartlib.features.base.BaseView;
import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.BorrowedBooks;

import java.util.ArrayList;
import java.util.List;

class BorrowBooksModel  {
    private BorrowBooksView view;
    public BorrowBooksModel(BorrowBooksView borrowBooksview){
        view = borrowBooksview;
    }
    public void init(){
        System.out.println("BorrowBooksModel " + view);
    }
    public void borrowBookForUser(String userId, String bookId) {
        if(userId == null || bookId == null || userId.isEmpty() || bookId.isEmpty()){
            view.displayErrorMessage();
            return;
        }
        SmartLibDb.getInstance().borrowBook(userId, bookId);
        view.displaySuccessMessage();
    }
    public void showBorrowedBookdetails(String userId){
        List<BorrowedBooks> borrowedList = SmartLibDb.getInstance().getBorrowedBooksByUser(userId);
    }


}
