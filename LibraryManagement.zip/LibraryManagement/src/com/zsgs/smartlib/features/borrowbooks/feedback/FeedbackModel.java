package com.zsgs.smartlib.features.borrowbooks.feedback;

class FeedbackModel {
   private  FeedbackView view;
   public FeedbackModel(FeedbackView feedbackView){
       view = feedbackView;
   }
   public void init(){
       System.out.println( " FeedbackModel "+view);
   }


}
