package com.zsgs.smartlib.features.borrowbooks.fine;

public class FineModel {
    private FineView view;
    public FineModel(FineView fineView){
        view = fineView;
    }
    public void init(){
        System.out.println("FineModel " +view);
    }

}
