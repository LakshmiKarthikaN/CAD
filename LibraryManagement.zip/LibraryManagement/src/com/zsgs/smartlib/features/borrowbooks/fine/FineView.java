package com.zsgs.smartlib.features.borrowbooks.fine;

public class FineView {
    FineModel model;
    public FineView(){
        model = new FineModel(this);
    }
    public void init(){
        System.out.println("FineView" +model);
    }
}
