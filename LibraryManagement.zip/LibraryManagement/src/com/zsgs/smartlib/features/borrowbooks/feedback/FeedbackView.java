package com.zsgs.smartlib.features.borrowbooks.feedback;

public class FeedbackView {
     FeedbackModel model;
     public FeedbackView(){
         model = new FeedbackModel(this);
     }
     public void init(){
         System.out.println( " FeedbackView " +model);
     }

}
