package com.zsgs.smartlib.features.books.details;


import com.zsgs.smartlib.features.base.BaseView;
import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.Books;
import java.util.Optional;

class DetailsModel extends BaseView {
    private final DetailsView view;
    public DetailsModel(DetailsView detailsView){
        view=detailsView;
    }
    public void init(){
        System.out.println("DetailsView" +view);
    }
    void getBookDetails(String bookId) {
        if (bookId == null || bookId.trim().isEmpty()) {
            view.showMessage("Please enter a valid Book ID.");
            return;
        }

        Optional<Books> book = SmartLibDb.getInstance().getAllBooks().stream()
                .filter(b -> b.getId().equals(bookId))
                .findFirst();

        view.displayBookDetails(book.orElse(null));
    }
}
