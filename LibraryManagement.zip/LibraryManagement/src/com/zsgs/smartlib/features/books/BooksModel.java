package com.zsgs.smartlib.features.books;

import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.Books;

import java.util.List;

public class BooksModel {
    BooksView view;
    public BooksModel(BooksView booksview){
        this.view = booksview;
    }
//    public void init(){
//
//    }

    void viewAllBooks() {
        List<Books> books = SmartLibDb.getInstance().getAllBooks();
        view.displayBooks(books);
    }
}
