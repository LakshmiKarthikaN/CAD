package com.zsgs.smartlib.features.books.manage;


import com.zsgs.smartlib.repositary.db.SmartLibDb;
import com.zsgs.smartlib.repositary.dto.Books;
import java.util.List;
import java.util.UUID;
public class ManageModel {
    private final ManageView view;

    public ManageModel(ManageView manageView) {
        view = manageView;
    }
//
//    public void init() {
//        System.out.println("ManageView " + view);
//    }
    void addBook(Books book){
        if(validateBook(book)){
            book.setId(generateBookId());
            SmartLibDb.getInstance().addBook(book);
            view.showSuccessMessage("Book added Successfully");
        }else{
            view.showErroMessage("Invalid book information. please try again.");
        }
    }
    void viewAllBooks(){
        List<Books> books = SmartLibDb.getInstance().getAllBooks();
        view.displayBooks(books);
    }
    private boolean validateBook(Books book) {
        return book != null &&
                book.getName() != null && !book.getName().trim().isEmpty() &&
                book.getAuthor() != null && !book.getAuthor().trim().isEmpty() &&
                book.getGenre() != null && !book.getGenre().trim().isEmpty() &&
                book.getVolume() > 0 &&
                book.getPublishedYear() != null && book.getPublishedYear() >= 1800 && book.getPublishedYear() <= 2024 &&
                book.getNoOfCopy() > 0 &&
                book.getAvailableCount() >= 0 && book.getAvailableCount() <= book.getNoOfCopy();
    }
    private String generateBookId() {
        return "BK" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

}
