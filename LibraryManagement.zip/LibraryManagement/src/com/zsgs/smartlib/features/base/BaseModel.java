package com.zsgs.smartlib.features.base;

public class BaseModel {
}
