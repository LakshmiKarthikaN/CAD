package com.zsgs.smartlib.features.base;

import com.zsgs.smartlib.features.registration.RegistrationView;

public abstract class BaseView {
    protected void logoutApp(){
        System.out.println("Logging out...");
        new RegistrationView().init();
    }
    protected void exitApp(){
        System.out.println("Thanks you for using SmartLib");
    }
    public void showMessage(String message){
        System.out.println(message);
    }

}
