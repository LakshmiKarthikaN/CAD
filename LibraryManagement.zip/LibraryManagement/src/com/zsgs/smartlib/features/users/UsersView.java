package com.zsgs.smartlib.features.users;

public class UsersView {
    UsersModel model;
    public UsersView(){
        model=new UsersModel(this);
    }
    public void init(){
        System.out.println("Usersview" +model);
    }


}
