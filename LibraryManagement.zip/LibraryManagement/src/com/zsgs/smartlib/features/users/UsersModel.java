package com.zsgs.smartlib.features.users;



public class UsersModel {
    private UsersView view;
    public UsersModel(UsersView usersview){
         view = usersview;
    }void init(){
        System.out.println("UsersModel" +view);
    }


}
