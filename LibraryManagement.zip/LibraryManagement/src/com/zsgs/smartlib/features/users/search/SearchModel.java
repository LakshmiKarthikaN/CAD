package com.zsgs.smartlib.features.users.search;

class SearchModel {
    private  SearchView view;
    public SearchModel(SearchView searchView){

        view = searchView;
    }
    public void init(){
        System.out.println("SearchView"+view);
    }

}
