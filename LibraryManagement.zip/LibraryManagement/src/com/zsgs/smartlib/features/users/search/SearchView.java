package com.zsgs.smartlib.features.users.search;

public class SearchView {
    SearchModel model;
    public SearchView(){
        model = new SearchModel(this);
    }
    public void init(){
        System.out.println(" SearchView "+model);
    }
}
