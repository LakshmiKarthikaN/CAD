import com.zsgs.spotlightbookings.features.bookings.cancellation.CancellationView;
import com.zsgs.spotlightbookings.features.bookings.feedback.FeedbackView;
import com.zsgs.spotlightbookings.features.bookings.payment.paymentmethod.PaymentView;
import com.zsgs.spotlightbookings.features.bookings.refundpolicy.RefundPolicyView;
import com.zsgs.spotlightbookings.features.movies.notifymovies.NotifyMoviesView;
import com.zsgs.spotlightbookings.features.registration.RegistrationView;
import com.zsgs.spotlightbookings.features.users.details.DetailsView;
import com.zsgs.spotlightbookings.features.users.manage.ManageView;
import com.zsgs.spotlightbookings.features.users.search.SearchView;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.printf("Hello and welcome!");

        new RegistrationView();
        new FeedbackView();
        new DetailsView();
        new ManageView();
        new SearchView();
        new RefundPolicyView();
        new CancellationView();
        new PaymentView();
        new DetailsView();
        new NotifyMoviesView();
    }
}