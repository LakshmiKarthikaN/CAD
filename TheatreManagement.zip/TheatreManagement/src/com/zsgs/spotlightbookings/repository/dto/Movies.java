package com.zsgs.spotlightbookings.repository.dto;

public class Movies {
    Integer movieId;
    String title;
    String genre;
    long releaseDate;
    boolean isReRelease;
}
