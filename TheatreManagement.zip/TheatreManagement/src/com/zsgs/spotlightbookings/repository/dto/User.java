package com.zsgs.spotlightbookings.repository.dto;

public class User {
    String userId;
    String name;
    String mailId;
    String password;
    long mobileNo;
    boolean isRepeatedCustomer;
    String Location;
}
