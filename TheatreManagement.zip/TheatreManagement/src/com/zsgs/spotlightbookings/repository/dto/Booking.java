package com.zsgs.spotlightbookings.repository.dto;

public class Booking {
    Integer BookingId;
    User user;
    Show show;
    Payment payment;
    boolean iscancelled;
}
