package com.zsgs.spotlightbookings.repository.dto;
import java.util.List;
public class Show {
    String showId;
    Movies movie;
    List<String> ShowType;
}
