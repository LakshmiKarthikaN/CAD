package com.zsgs.spotlightbookings.repository.dto;
import java.util.List;
public class Seat {
    Integer seatNo;
    Boolean isAvailable;
    enum SeatType {Non_Ac, Ac};
    List<Seat> seats;
}
