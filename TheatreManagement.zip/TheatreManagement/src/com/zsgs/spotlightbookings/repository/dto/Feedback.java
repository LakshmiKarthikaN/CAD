package com.zsgs.spotlightbookings.repository.dto;

public class Feedback {
    String mailId;
    String message;

}
