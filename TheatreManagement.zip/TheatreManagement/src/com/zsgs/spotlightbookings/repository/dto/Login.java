package com.zsgs.spotlightbookings.repository.dto;

public class Login {
    String mailId;
    String password;
}
