package com.zsgs.spotlightbookings.repository.dto;

public class Theatre {
    Integer TheatreId;
    String address;
    String name;
}
