package com.zsgs.spotlightbookings.repository.dto;

public class Payment {
    Integer paymentId;
    double amount;
    String PaymentMethod;
    boolean isPaid;
    boolean isRefunded;
}
