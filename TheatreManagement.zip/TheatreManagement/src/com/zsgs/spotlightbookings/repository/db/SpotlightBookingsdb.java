package com.zsgs.spotlightbookings.repository.db;

public class SpotlightBookingsdb {
}
