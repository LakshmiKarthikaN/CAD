package com.zsgs.spotlightbookings.features.bookings.feedback;

public class FeedbackView {
    FeedbackModel model;
    public FeedbackView(){
        model = new FeedbackModel(this);
    }

}
