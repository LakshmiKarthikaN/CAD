package com.zsgs.spotlightbookings.features.bookings.cancellation;

public class CancellationView {
    CancellationModel model;
    public CancellationView(){
        model = new CancellationModel(this);
    }
}
