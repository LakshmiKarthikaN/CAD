package com.zsgs.spotlightbookings.features.bookings;

 class BookingsModel {
    private final BookingsView view;
    public BookingsModel(BookingsView bookingsview){
        view = bookingsview;
    }
}
