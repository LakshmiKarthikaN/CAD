package com.zsgs.spotlightbookings.features.bookings.confirmation;

public class ConfirmationView {
    ConfirmationModel model;
    public ConfirmationView(){
        model = new ConfirmationModel(this);
    }
}
