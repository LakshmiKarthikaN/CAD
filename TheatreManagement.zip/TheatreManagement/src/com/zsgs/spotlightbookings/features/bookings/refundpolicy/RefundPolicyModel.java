package com.zsgs.spotlightbookings.features.bookings.refundpolicy;

public class RefundPolicyModel {
    RefundPolicyView view;
    public RefundPolicyModel(RefundPolicyView refundpolicyView){
        view = refundpolicyView;
    }
}
