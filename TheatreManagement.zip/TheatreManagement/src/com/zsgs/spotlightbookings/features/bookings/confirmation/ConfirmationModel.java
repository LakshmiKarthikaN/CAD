package com.zsgs.spotlightbookings.features.bookings.confirmation;

 class ConfirmationModel {
    private final ConfirmationView view;
    public ConfirmationModel(ConfirmationView confirmationview){
        view = confirmationview;

    }

}
