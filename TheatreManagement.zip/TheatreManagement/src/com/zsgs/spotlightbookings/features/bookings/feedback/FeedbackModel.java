package com.zsgs.spotlightbookings.features.bookings.feedback;

 class FeedbackModel {
    private FeedbackView view;
    public FeedbackModel(FeedbackView feedbackview){
        view = feedbackview;
    }
}
