package com.zsgs.spotlightbookings.features.bookings.payment.paymentmethod;

class PaymentModel {
     private final PaymentView view;
     public PaymentModel(PaymentView paymentview){
         view = paymentview;;
     }
}
