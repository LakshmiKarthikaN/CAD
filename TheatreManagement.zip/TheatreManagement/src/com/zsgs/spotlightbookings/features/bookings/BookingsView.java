package com.zsgs.spotlightbookings.features.bookings;

public class BookingsView {
    BookingsModel model;
    public BookingsView(){
        model = new BookingsModel(this);
    }
}
