package com.zsgs.spotlightbookings.features.bookings.refundpolicy;

public class RefundPolicyView {
    RefundPolicyModel model;
    public RefundPolicyView(){
        model = new RefundPolicyModel(this);
    }
}
