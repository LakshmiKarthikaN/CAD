package com.zsgs.spotlightbookings.features.bookings.payment.onlineticketoffers;

public class OnlineTicketOffersView {
    OnlineTicketOffersModel model;
    public OnlineTicketOffersView(){
        model = new OnlineTicketOffersModel(this);
    }
}
