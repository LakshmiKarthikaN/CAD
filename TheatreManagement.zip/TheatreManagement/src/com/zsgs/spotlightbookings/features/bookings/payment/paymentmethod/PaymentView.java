package com.zsgs.spotlightbookings.features.bookings.payment.paymentmethod;

public class PaymentView {
    PaymentModel model;
    public PaymentView(){
        model = new PaymentModel(this);
    }
}
