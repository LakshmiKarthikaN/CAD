package com.zsgs.spotlightbookings.features.bookings.payment.onlineticketoffers;

class OnlineTicketOffersModel {
    private OnlineTicketOffersView view;
    public OnlineTicketOffersModel(OnlineTicketOffersView onlineticketoffersView){
        view = onlineticketoffersView;
    }

}
