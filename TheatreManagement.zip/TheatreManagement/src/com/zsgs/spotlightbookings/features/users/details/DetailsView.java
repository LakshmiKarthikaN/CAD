package com.zsgs.spotlightbookings.features.users.details;

public class DetailsView {
    DetailsModel model;
    public DetailsView(){
        model=new DetailsModel(this);
    }
    public void init(){
        model.init();
        System.out.println(" DetailsModel "+model);
    }
}
