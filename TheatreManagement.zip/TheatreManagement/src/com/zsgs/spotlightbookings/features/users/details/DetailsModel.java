package com.zsgs.spotlightbookings.features.users.details;

public class DetailsModel {
    private final DetailsView view;
    public DetailsModel(DetailsView detailsView){
        view=detailsView;
    }
    public void init(){
        System.out.println("DetailsView" +view);
    }
}
