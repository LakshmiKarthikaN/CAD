package com.zsgs.spotlightbookings.features.users.manage;

public class ManageView {
    ManageModel model;
    public ManageView(){
        model = new ManageModel(this);
    }
    public void init(){
        System.out.println("ManageModel"+model);
    }
}
