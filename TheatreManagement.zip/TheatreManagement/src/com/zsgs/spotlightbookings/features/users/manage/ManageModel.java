package com.zsgs.spotlightbookings.features.users.manage;

public class ManageModel {
    private final ManageView view;
    public ManageModel(ManageView manageView){
        view = manageView;
    }
    public void init(){
        System.out.println("ManageView " +view);
    }
}
