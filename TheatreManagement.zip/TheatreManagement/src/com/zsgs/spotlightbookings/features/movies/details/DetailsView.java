package com.zsgs.spotlightbookings.features.movies.details;

public class DetailsView {
    DetailsModel model;
    public DetailsView(){
        model = new DetailsModel(this);
    }
}
