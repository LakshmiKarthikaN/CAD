package com.zsgs.spotlightbookings.features.movies.notifymovies;

public class NotifyMoviesView {
    NotifyMoviesModel model;
    public NotifyMoviesView(){
        model = new NotifyMoviesModel(this);
    }
}
