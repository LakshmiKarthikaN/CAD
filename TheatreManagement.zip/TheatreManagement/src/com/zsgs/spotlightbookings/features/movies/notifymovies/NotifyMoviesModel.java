package com.zsgs.spotlightbookings.features.movies.notifymovies;

class NotifyMoviesModel {
    private NotifyMoviesView view;
    public NotifyMoviesModel(NotifyMoviesView notifyMoviesView){
        view = notifyMoviesView;
    }
}
