package com.zsgs.spotlightbookings.features.movies.details;
//Add Movies
class DetailsModel {
    private DetailsView view;
    public DetailsModel(DetailsView detailsview){
         view = detailsview;
    }
}
