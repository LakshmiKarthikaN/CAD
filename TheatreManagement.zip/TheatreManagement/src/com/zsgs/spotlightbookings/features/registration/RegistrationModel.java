package com.zsgs.spotlightbookings.features.registration;

class RegistrationModel {
     RegistrationView view;
     public RegistrationModel(RegistrationView registrationview){
         view = registrationview;
     }

}
