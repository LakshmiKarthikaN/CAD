package com.zsgs.spotlightbookings.features.registration;

public class RegistrationView {
    RegistrationModel model;
    public RegistrationView(){
        model = new RegistrationModel(this);
    }

}
