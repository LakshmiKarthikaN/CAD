package com.zsgs.gobus.repository.dto;

public class Feedback {
    String message;
    String name;
}
