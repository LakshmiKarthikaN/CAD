package com.zsgs.gobus.repository.dto;

public class payment {
    String paymentId;
    //double amount;
    String paymentMethod;

}
