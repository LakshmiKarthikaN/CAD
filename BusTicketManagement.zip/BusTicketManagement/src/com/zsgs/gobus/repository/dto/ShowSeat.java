package com.zsgs.gobus.repository.dto;

public class ShowSeat {
    String seatNumber;
    boolean isBooked;
    //SeatType type; // enum: SLEEPER, NON_SLEEPER
    enum SeatType { SLEEPER, NON_SLEEPER }
}
