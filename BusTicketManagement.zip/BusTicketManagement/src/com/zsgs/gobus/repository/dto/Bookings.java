package com.zsgs.gobus.repository.dto;

public class Bookings {
    String source;
    String destination;
    long date;
}
