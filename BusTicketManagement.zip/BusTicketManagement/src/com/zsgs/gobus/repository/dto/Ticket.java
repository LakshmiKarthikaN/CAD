package com.zsgs.gobus.repository.dto;

public class Ticket {
    String TicketId;
    String Username;
    Integer busNo;
    double price;


}
