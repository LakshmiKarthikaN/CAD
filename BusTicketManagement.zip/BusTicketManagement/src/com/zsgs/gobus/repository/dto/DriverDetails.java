package com.zsgs.gobus.repository.dto;

public class DriverDetails {

    String driverId;
    String name;
    String phone;
}
