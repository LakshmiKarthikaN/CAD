package com.zsgs.gobus.repository.dto;

public class Route {
    String routeId;
    String startPoint;
    String endPoint;
    //<String> stopPoints;
    double distance;
}
