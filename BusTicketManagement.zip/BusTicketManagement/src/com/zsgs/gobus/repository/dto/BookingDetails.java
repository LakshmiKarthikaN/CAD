package com.zsgs.gobus.repository.dto;

public class BookingDetails {
    String Username;
    Integer Id;
    enum gender {female,male,others};
    int age;
    String SeatType;
}
