package com.zsgs.gobus.repository.dto;
import java.util.List;
public class ShowBus {
    List<String> AvailableBus;
}
