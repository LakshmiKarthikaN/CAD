package com.zsgs.gobus.repository.dto;
import java.util.List;

public class BusDetails {
    String busId;
    String busName;
    Route route;
    List<String> seats;

    String startTime;
    String endTime;
}
