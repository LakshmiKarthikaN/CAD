package com.zsgs.gobus.repository.features.bookings.refundpolicy;

public class RefundPolicyModel {
    private RefundPolicyView view;
    public RefundPolicyModel(RefundPolicyView refundpolicyview){
        view=refundpolicyview;
    }
}
