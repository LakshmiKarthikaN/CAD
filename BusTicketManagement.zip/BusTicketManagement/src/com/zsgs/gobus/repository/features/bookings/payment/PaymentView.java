package com.zsgs.gobus.repository.features.bookings.payment;

public class PaymentView {
    PaymentModel model;
    public PaymentView(){
        model = new PaymentModel(this);
    }

}
