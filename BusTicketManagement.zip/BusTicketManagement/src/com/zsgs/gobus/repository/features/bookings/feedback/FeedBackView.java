package com.zsgs.gobus.repository.features.bookings.feedback;

public class FeedBackView {
    FeedBackModel model;
    public FeedBackView(){
        model = new FeedBackModel(this);
    }
}
