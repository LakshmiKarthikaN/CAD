package com.zsgs.gobus.repository.features.bookings.feedback;

public class FeedBackModel {

    private FeedBackView view;
    public FeedBackModel(FeedBackView feedbackview){
        view = feedbackview;
    }

}
