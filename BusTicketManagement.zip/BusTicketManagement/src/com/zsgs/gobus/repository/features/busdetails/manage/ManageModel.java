package com.zsgs.gobus.repository.features.busdetails.manage;

public class ManageModel {
}
