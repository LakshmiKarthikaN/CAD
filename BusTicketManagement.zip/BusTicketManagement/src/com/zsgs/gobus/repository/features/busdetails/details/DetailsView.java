package com.zsgs.gobus.repository.features.busdetails.details;

public class DetailsView {
}
