package com.zsgs.gobus.repository.features.bookings.cancellation;

class CancellationModel {
    CancellationView view;
    public CancellationModel(CancellationView cancellationView){
        view = cancellationView;
    }



}
