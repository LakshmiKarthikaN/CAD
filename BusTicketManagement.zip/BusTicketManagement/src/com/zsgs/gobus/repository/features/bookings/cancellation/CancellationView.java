package com.zsgs.gobus.repository.features.bookings.cancellation;

public class CancellationView {
    CancellationModel model;
    public CancellationView(){
        model = new CancellationModel(this);
    }


}
