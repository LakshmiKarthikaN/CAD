package com.zsgs.gobus.repository.features.bookings.payment;

public class PaymentModel {
    private PaymentView view;
    public PaymentModel(PaymentView paymentview){
        view = paymentview;
    }

}
