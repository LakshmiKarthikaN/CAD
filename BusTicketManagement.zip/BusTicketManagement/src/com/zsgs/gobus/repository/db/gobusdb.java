package com.zsgs.gobus.repository.db;

public class gobusdb {
}
